# ddos-discord-bot
I may not be held responsible for any damage caused by my code. This project is purely made for 'Proof-Of-Concept', educational purposes, and stress-testing your own networks and IoT devices to test your DDoS protection. I do not tolerate any illegal use of my code, and the user is responsible for everything that he/she/they do with my code.

This was created because a lot of script kiddies have been making poorly coded Discord DDoS bots, they used requests.get/post for Discord Bots, they used unclean code, they used poor grammar on the bots, and so on.

With poor grammar, I refer to the little school-drop-outs that say 'your' instead of 'you're', 'i' instead of 'I', 'dont' instead of 'don't', and so on. These little children should pay attention in school. Such grammar mistakes make you look more silly, and therefore you will archive less.

This was made by XxBiancaXx#4356.

# Check me out!
https://www.github.com/XxB1a/ddos-discord-bot
<br>
https://www.instagram.com/moron420
<br>
XxBiancaXx#4356

# Important note!!
This bot will only work if you read thru the code and change whatever is needed. Tokens, API_DATA, MAXTIME, etc. are examples of things that MUST be changed!
